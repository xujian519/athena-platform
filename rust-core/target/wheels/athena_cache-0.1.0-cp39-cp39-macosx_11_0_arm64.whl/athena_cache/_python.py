"""
Python回退实现 - 用于开发环境

当Rust模块未编译时使用的纯Python实现。
性能约为Rust版本的1/10-1/100。
"""

from typing import Any, Optional, Dict
from collections import OrderedDict
import threading


class LRUCache:
    """Python版LRU缓存（开发用）"""

    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self.cache: OrderedDict = OrderedDict()
        self.lock = threading.RLock()

    def get(self, key: str) -> Optional[Any]:
        with self.lock:
            if key in self.cache:
                # 移到末尾（最近使用）
                self.cache.move_to_end(key)
                return self.cache[key]
            return None

    def put(self, key: str, value: Any) -> bool:
        with self.lock:
            if key in self.cache:
                self.cache.move_to_end(key)
            self.cache[key] = value

            # LRU淘汰
            if len(self.cache) > self.max_size:
                self.cache.popitem(last=False)
            return True

    def remove(self, key: str) -> bool:
        with self.lock:
            if key in self.cache:
                del self.cache[key]
                return True
            return False

    def clear(self):
        with self.lock:
            self.cache.clear()

    def size(self) -> int:
        with self.lock:
            return len(self.cache)


class CacheStats:
    """缓存统计信息"""

    def __init__(self):
        self.hits = 0
        self.misses = 0
        self.evictions = 0

    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0


class TieredCache:
    """分层缓存（Python回退版）"""

    def __init__(
        self,
        hot_size: int = 1000,
        warm_size: int = 10000,
        cold_size: int = 100000,
    ):
        self.hot_cache = LRUCache(max_size=hot_size)
        self.warm_cache = LRUCache(max_size=warm_size)
        self.cold_cache: Dict[str, Any] = {}
        self.stats = CacheStats()
        self.lock = threading.RLock()

    def get(self, key: str) -> Optional[Any]:
        with self.lock:
            # HOT层
            value = self.hot_cache.get(key)
            if value is not None:
                self.stats.hits += 1
                return value

            # WARM层
            value = self.warm_cache.get(key)
            if value is not None:
                self.stats.hits += 1
                # 提升到HOT层
                self.hot_cache.put(key, value)
                return value

            # COLD层
            value = self.cold_cache.get(key)
            if value is not None:
                self.stats.hits += 1
                # 提升到WARM层
                self.warm_cache.put(key, value)
                return value

            self.stats.misses += 1
            return None

    def put(self, key: str, value: Any) -> bool:
        with self.lock:
            # 默认放入WARM层
            return self.warm_cache.put(key, value)

    def remove(self, key: str) -> bool:
        with self.lock:
            removed = False
            removed |= self.hot_cache.remove(key)
            removed |= self.warm_cache.remove(key)
            if key in self.cold_cache:
                del self.cold_cache[key]
                removed = True
            return removed

    def clear(self):
        with self.lock:
            self.hot_cache.clear()
            self.warm_cache.clear()
            self.cold_cache.clear()

    def get_stats(self) -> CacheStats:
        return self.stats


# 导出
__all__ = ["TieredCache", "CacheStats", "LRUCache"]
