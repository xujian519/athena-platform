"""
Athena高性能缓存引擎 - Python接口

提供分层缓存、LRU淘汰、并发安全的高性能缓存实现。

性能特性：
- 比Python dict快10-100倍
- 线程安全，支持高并发
- 自动LRU淘汰
- 分层缓存（HOT→WARM→COLD）

使用示例：
    >>> from athena_cache import TieredCache
    >>> cache = TieredCache(max_size=10000)
    >>> cache.put("key", "value")
    >>> cache.get("key")
    'value'
"""

# Rust FFI导入
try:
    from ._core import *
    __all__ = [
        "TieredCache",
        "CacheStats",
    ]
except ImportError:
    # 开发模式下，Rust模块可能未编译
    __all__ = []
    import warnings
    warnings.warn(
        "Rust加速模块未加载，使用Python回退实现（性能较慢）",
        ImportWarning,
    )

__version__ = "0.1.0"
__author__ = "Athena Team"
__license__ = "MIT"


def __dir__():
    return __all__ + ["__version__", "__author__", "__license__"]
